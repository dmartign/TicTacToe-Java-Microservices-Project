package hw3q1;

public class Utils {

    public static boolean nullOrBlank(String parameter) {
        return parameter == null || "".equals(parameter);
    }
}
