package cse551.tbd.authentication.controller.dto;

import lombok.Data;

@Data
public class LogoutResponse {

}
